
# Numpy

1. Numpy is for faster numerical calculations.

** Importing numpy package


```python
import numpy as np
```

** Creating a Numpy Array


```python
a = np.array([1, 2, 3, 4, 5, 6])
print(a)
print(a[-1])
```

    [1 2 3 4 5 6]
    6
    

** Methods in Numpy


```python
a.size

```




    6




```python
a.dtype
```




    dtype('int32')




```python
a.shape
```




    (6,)




```python
a.itemsize
```




    4



** Creating a floating point array


```python
b = np.array([1, 2, 3], dtype =float)
print(b)
```

    [ 1.  2.  3.]
    


```python
c = np.array([[0, 1, 2, 3], [10, 11 , 12, 13]])
print(c)
```

    [[ 0  1  2  3]
     [10 11 12 13]]
    


```python
c.shape
```




    (2, 4)



** Creating a 3-D Array


```python
d = np.array([[[1, 2, 3],
               [4, 5, 6]],
              
              [[7, 8, 9],
               [10, 11, 12]]])

print(d)
```

    [[[ 1  2  3]
      [ 4  5  6]]
    
     [[ 7  8  9]
      [10 11 12]]]
    


```python
d.shape
```




    (2, 2, 3)




```python
e = np.arange(10)
print(e)
```

    [0 1 2 3 4 5 6 7 8 9]
    


```python
f = np.arange(1, 9, 2)
print(f)
```

    [1 3 5 7]
    


```python
g = np.linspace(0, 1, 6) # linspace = Linearly spaced points
print(g)
```

    [ 0.   0.2  0.4  0.6  0.8  1. ]
    

** Creation of Common Arrays


```python
h = np.ones((3, 3))
print(h)
```

    [[ 1.  1.  1.]
     [ 1.  1.  1.]
     [ 1.  1.  1.]]
    


```python
i = np.zeros((2, 2))
print(i)
```

    [[ 0.  0.]
     [ 0.  0.]]
    


```python
j = np.identity(3)
print(j)
```

    [[ 1.  0.  0.]
     [ 0.  1.  0.]
     [ 0.  0.  1.]]
    


```python
k = np.diag([1, 2, 3, 4])
print(k)
```

    [[1 0 0 0]
     [0 2 0 0]
     [0 0 3 0]
     [0 0 0 4]]
    


```python
l = np.random.random((3, 2))
print(l)
```

    [[ 0.45536268  0.23629071]
     [ 0.37011122  0.2058875 ]
     [ 0.9898844   0.25712247]]
    


```python
m = np.ones_like(l, float)
print(m)
```

    [[ 1.  1.]
     [ 1.  1.]
     [ 1.  1.]]
    


```python
n = np.zeros_like(l, float)
print(n)
```

    [[ 0.  0.]
     [ 0.  0.]
     [ 0.  0.]]
    

** Transpose of a numpy array


```python
o = l.T
print(o)
```

    [[ 0.45536268  0.37011122  0.9898844 ]
     [ 0.23629071  0.2058875   0.25712247]]
    

** Accessing Array Elements


```python
print(a[-3])
```

    4
    


```python
print(c[1,3])
```

    13
    


```python
c[1, 3] = 0;
print(c)
```

    [[ 0  1  2  3]
     [10 11 12  0]]
    

** Arrays: Basic Operations


```python
p = np.array([1, 2, 3, 4])
q = np.array([4, 5 , 6, 7])
```


```python
print(p+q)
```

    [ 5  7  9 11]
    


```python
print(p-q)
```

    [-3 -3 -3 -3]
    


```python
print(p*q)
```

    [ 4 10 18 28]
    


```python
print(p/q)
```

    [ 0.25        0.4         0.5         0.57142857]
    


```python
 r= np.arange(10)
```

** Indexing and Slicing Arrays


```python
r[2:9:3]
```




    array([2, 5, 8])




```python
print(r[:4])
```

    [0 1 2 3]
    


```python
print(r[1:3])
```

    [1 2]
    


```python
print(r[::2])
```

    [0 2 4 6 8]
    


```python
print(r[3:])
```

    [3 4 5 6 7 8 9]
    


```python
print(h[0, 1:3])
```

    [ 1.  1.]
    


```python
print(h[1:, 1:])
```

    [[ 1.  1.]
     [ 1.  1.]]
    


```python
print(h[:, 2])
```

    [ 1.  1.  1.]
    

** Reshaping Arrays


```python
s = np.arange(12)
print(s)
```

    [ 0  1  2  3  4  5  6  7  8  9 10 11]
    


```python
t = s.reshape(3, 4) # Dimension of reshaping array should be factor of size of original array
print(t)
```

    [[ 0  1  2  3]
     [ 4  5  6  7]
     [ 8  9 10 11]]
    

** Array Math


```python
o = np.floor(o)
print(o)
```

    [[ 0.  0.  0.]
     [ 0.  0.  0.]]
    


```python
o = np.ceil(l)
print(o)
```

    [[ 1.  1.]
     [ 1.  1.]
     [ 1.  1.]]
    


```python
u = np.sin(p)
print(u)
```

    [ 0.84147098  0.90929743  0.14112001 -0.7568025 ]
    


```python
v = np.cos(p)
print(v)
```

    [ 0.54030231 -0.41614684 -0.9899925  -0.65364362]
    


```python
w = np.around(v, 2)
print(w)
```

    [ 0.54 -0.42 -0.99 -0.65]
    


```python
x = np.sqrt(p)
print(x)
```

    [ 1.          1.41421356  1.73205081  2.        ]
    

** Basic Visualization


```python
import matplotlib.pyplot as plt
x = np.linspace(0, 3, 20)
y = np.linspace(0, 9, 20)
plt.plot(x, y)      # Line plot
plt.plot(x, y, 'o') # Dot plot
plt.show()
```


![png](output_61_0.png)



```python
import matplotlib.pyplot as plt
x = np.linspace(0, 3, 20)
y = np.linspace(0, 9, 20)
plt.plot(x, y)      # Line plot
plt.plot(x, y, 'o') # Dot plot
plt.title('Example plot')
plt.xlabel('X Axis')
plt.ylabel('Y Axis')
plt.show()
```


![png](output_62_0.png)



```python
a1 = np.linspace(0, 2*np.pi, 50)
plt.plot(np.sin(a1))
plt.show()
```


![png](output_63_0.png)



```python
a2 = np.linspace(0, 2*np.pi, 50)
plt.plot(np.cos(a2))
plt.show()
```


![png](output_64_0.png)



```python
a3 = np.linspace(0, 2*np.pi, 50)
plt.plot(np.sin(a3), label = 'sin')
plt.plot(np.cos(a3), label = 'cos')
plt.legend()
plt.show()
```


![png](output_65_0.png)



```python
a4 = np.linspace(0, 2*np.pi, 50)
plt.plot(a4,np.sin(a4), 'b-o', 
         a4 ,np.cos(a4), 'r-^')
plt.show()
```


![png](output_66_0.png)



```python
a5 = np.random.random(200)
a6 = np.random.random(200)
plt.scatter(a5, a6, color = ['r', 'b'])
plt.show()
```


![png](output_67_0.png)



```python
plt.hist(np.random.random(200))
plt.show()
```


![png](output_68_0.png)



```python
plt.hist(np.random.random(200), 15)
plt.show()
```


![png](output_69_0.png)


** Basic Reductions


```python
sum = a.sum()
print(sum)
```

    21
    


```python
min = a.min()
print(min)
```

    1
    


```python
mean = a.mean()
print(mean)
```

    3.5
    


```python
std = a.std()
print(std)
```

    1.70782512766
    


```python
median = np.median(a) # 3.5 is the position of the median element
print(median)
```

    3.5
    


```python
loc_min = a.argmin()
loc_max = a.argmax()
loc_min, loc_max
```




    (0, 5)




```python
c
```




    array([[ 0,  1,  2,  3],
           [10, 11, 12,  0]])




```python
c.sum(axis = 0)
```




    array([10, 12, 14,  3])




```python
c.sum(axis = 1)
```




    array([ 6, 33])




```python
a7 = np.zeros((10, 10))
np.any(a7 != 0)
```




    False




```python
np.all(a7 == 0)
```




    True




```python
a8 = np.array([1, 2, 3, 2])
a9 = np.array([2, 2, 3, 2])
a10 = np.array([6, 4, 4, 5])
((a8<=a9) & (a9<=a10)).all()
```




    True


